#pragma once

void TestAllocationMismatch_malloc_delete();
void TestAllocationMismatch_malloc_deleteVec();
void TestAllocationMismatch_new_free();
void TestAllocationMismatch_newVec_free();

void TestHeapMismatch();
