
#define VLDVERSION          L"2.5.2"
#define VERSION_NUMBER		2,5,2,0
#define VERSION_STRING		"2.5.2.0"
#define VERSION_COPYRIGHT	"Copyright (C) 2005-2020"

#ifndef __FILE__
!define VLD_VERSION "2.5.2"	// NSIS Script
#endif
