#!/usr/bin/env bash
./buildconf
./configure
echo "Ran the setup script for muse including autoconf and executing ./configure"
