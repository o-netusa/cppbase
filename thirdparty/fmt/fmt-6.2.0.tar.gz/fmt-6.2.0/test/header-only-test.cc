// Header-only configuration test

#include "fmt/core.h"
